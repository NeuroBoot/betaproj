document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.getElementById('settings-btn');
    const icon = settingsBtn.querySelector('i');
    const body = document.body;

    function updateIcon(isDarkMode) {
        if (isDarkMode) {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
        } else {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
    }

    function toggleDarkMode() {
        const isCurrentlyDark = body.classList.contains('dark-mode');
        
        if (isCurrentlyDark) {
            body.classList.remove('dark-mode');
            body.classList.add('light-mode');
            localStorage.setItem('theme', 'light');
            updateIcon(false);
        } else {
            body.classList.remove('light-mode');
            body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
            updateIcon(true);
        }
    }

    const savedTheme = localStorage.getItem('theme');
    const isDark = (savedTheme === 'light') ? false : true; 

    if (!isDark) {
        body.classList.remove('dark-mode');
        body.classList.add('light-mode');
    } else {
        body.classList.add('dark-mode');
    }
    
    updateIcon(isDark);

    settingsBtn.addEventListener('click', toggleDarkMode);
});