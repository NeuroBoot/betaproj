document.addEventListener('DOMContentLoaded', function() {
    // === 1. وظيفة التحكم في حجم السايد بار (Sidebar Resize) ===
    const sidebar = document.querySelector('.sidebar');
    const resizer = document.querySelector('.resizer');

    if (resizer && sidebar) {
        resizer.addEventListener('mousedown', function (e) {
            e.preventDefault();
            document.addEventListener('mousemove', resize);
            document.addEventListener('mouseup', stopResize);
            document.body.style.cursor = 'col-resize';
        });

        function resize(e) {
            let newWidth = e.clientX;
            // قيود الحجم: بين 150px و 500px
            if (newWidth >= 150 && newWidth <= 500) {
                sidebar.style.width = newWidth + 'px';
            }
        }

        function stopResize() {
            document.removeEventListener('mousemove', resize);
            document.removeEventListener('mouseup', stopResize);
            document.body.style.cursor = 'default';
        }
    }

    // === 2. منطق إدارة الحسابات (أكوادك الأصلية كما هي) ===
    
    // عناصر نافذة الإضافة
    const modal = document.getElementById('accountModal');
    const openBtn = document.getElementById('openModalBtn');
    const closeBtn = document.getElementById('closeModalBtn');
    const accountForm = document.getElementById('accountForm');

    // عناصر نافذة التعديل
    const editModal = document.getElementById('editModal');
    const closeEditBtn = document.getElementById('closeEditModalBtn');
    const editForm = document.getElementById('editForm');
    
    const tableBody = document.getElementById('accountsTableBody');
    let currentRow; // متغير لتخزين السطر الذي يتم تعديله حالياً

    // --- وظائف نافذة الإضافة ---
    if (openBtn) openBtn.onclick = () => modal.style.display = 'flex';
    if (closeBtn) closeBtn.onclick = () => modal.style.display = 'none';

    accountForm.onsubmit = function(e) {
        e.preventDefault();
        const name = document.getElementById('fullName').value;
        const email = document.getElementById('email').value;
        const role = document.getElementById('role').value;
        const id = document.getElementById('idNumber').value;

        addNewRow(id, name, email, role);
        modal.style.display = 'none';
        accountForm.reset();
    };

    // --- وظائف التعديل والحذف (داخل الجدول) ---
    tableBody.addEventListener('click', function(e) {
        // 1. عند الضغط على Delete
        if (e.target.closest('.btn-delete')) {
            e.target.closest('tr').remove();
        }

        // 2. عند الضغط على Edit
        if (e.target.closest('.btn-edit')) {
            currentRow = e.target.closest('tr');
            
            // سحب البيانات الحالية من الجدول لوضعها في النافذة
            const cells = currentRow.getElementsByTagName('td');
            document.getElementById('editIdNumber').value = cells[0].innerText;
            document.getElementById('editFullName').value = cells[1].innerText;
            document.getElementById('editEmail').value = cells[2].innerText;
            
            // لضبط قيمة الـ Select عند التعديل
            const currentRole = cells[3].innerText.trim();
            document.getElementById('editRole').value = currentRole;

            editModal.style.display = 'flex';
        }
    });

    // --- حفظ التعديلات ---
    editForm.onsubmit = function(e) {
        e.preventDefault();
        
        // تحديث بيانات السطر الحالي بالقيم الجديدة من النافذة
        const cells = currentRow.getElementsByTagName('td');
        const role = document.getElementById('editRole').value;

        cells[0].innerText = document.getElementById('editIdNumber').value;
        cells[1].innerText = document.getElementById('editFullName').value;
        cells[2].innerText = document.getElementById('editEmail').value;
        cells[3].innerHTML = `<span class="badge ${role.toLowerCase()}">${role}</span>`;

        editModal.style.display = 'none';
    };

    if (closeEditBtn) closeEditBtn.onclick = () => editModal.style.display = 'none';

    // وظيفة مساعدة لإضافة سطر جديد
    function addNewRow(id, name, email, role) {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${id}</td>
            <td>${name}</td>
            <td>${email}</td>
            <td><span class="badge ${role.toLowerCase()}">${role}</span></td>
            <td><span class="status-active">Active</span></td>
            <td class="actions">
                <button class="btn-edit"><i class="fas fa-edit"></i> Edit</button>
                <button class="btn-delete"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tableBody.appendChild(newRow);
    }

    // إغلاق أي نافذة عند الضغط في الخارج
    window.onclick = (e) => {
        if (e.target == modal) modal.style.display = 'none';
        if (e.target == editModal) editModal.style.display = 'none';
    };
});