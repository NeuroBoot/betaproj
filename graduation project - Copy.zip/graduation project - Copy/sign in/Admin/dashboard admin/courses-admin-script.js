// المتغيرات الأساسية للـ Sidebar
const sidebar = document.getElementById("resizableSidebar");
const resizer = document.getElementById("sidebarResizer");
const mainContent = document.getElementById("mainContent");
let currentRow = null; // متغير عالمي عشان نعرف بنعدل في أنهي صف

// 1. منطق الـ Resizer
if (resizer) {
    resizer.addEventListener("mousedown", (e) => {
        e.preventDefault();
        document.addEventListener("mousemove", resize);
        document.addEventListener("mouseup", stopResize);
    });
}

function resize(e) {
    let newWidth = e.clientX;
    if (newWidth > 180 && newWidth < 450) {
        sidebar.style.width = newWidth + "px";
        mainContent.style.marginLeft = newWidth + "px";
    }
}

function stopResize() {
    document.removeEventListener("mousemove", resize);
}

// 2. تبديل الثيم (Dark/Light Mode)
function toggleTheme() {
    document.body.classList.toggle("light-mode");
    const isLight = document.body.classList.contains("light-mode");
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
    
    const modeIcon = document.getElementById("modeIcon");
    const modeText = document.getElementById("modeText");
    if (modeIcon) modeIcon.className = isLight ? "fas fa-sun" : "fas fa-moon";
    if (modeText) modeText.innerText = isLight ? "Light Mode" : "Dark Mode";
}

window.onload = () => {
    if (localStorage.getItem('theme') === 'light') {
        document.body.classList.add('light-mode');
        const modeIcon = document.getElementById("modeIcon");
        const modeText = document.getElementById("modeText");
        if (modeIcon) modeIcon.className = "fas fa-sun";
        if (modeText) modeText.innerText = "Light Mode";
    }
};

// 3. دوال الـ Modal والعمليات (Add / Edit / Delete)

function openModal() {
    currentRow = null; // تصفير الصف عشان نضمن إنها "إضافة" مش "تعديل"
    document.getElementById("courseModal").style.display = "block";
    document.querySelector(".modal-header h3").innerText = "Add New Course";
    document.querySelector(".btn-submit").innerText = "Add Course";
    document.getElementById("addCourseForm").reset();
}

function closeModal() {
    document.getElementById("courseModal").style.display = "none";
    document.getElementById("addCourseForm").reset();
}

// دالة التعديل (Edit)
function editCourse(btn) {
    currentRow = btn.closest("tr"); // تحديد الصف اللي ضغطنا عليه
    const cells = currentRow.querySelectorAll("td");

    // ملء بيانات الفورم من بيانات الجدول
    const inputs = document.querySelectorAll("#addCourseForm input");
    const select = document.querySelector("#addCourseForm select");

    inputs[0].value = cells[1].innerText; // Course Name
    inputs[1].value = cells[0].innerText; // Course Code
    inputs[2].value = cells[4].innerText; // Sections
    
    // اختيار المدرس الصح من الـ Select
    for (let option of select.options) {
        if (option.text === cells[2].innerText) {
            select.value = option.value;
            break;
        }
    }

    // تغيير شكل المودال لـ "تعديل"
    document.getElementById("courseModal").style.display = "block";
    document.querySelector(".modal-header h3").innerText = "Edit Course";
    document.querySelector(".btn-submit").innerText = "Update Course";
}

// دالة الحذف (Delete)
function deleteCourse(btn) {
    if (confirm("Are you sure you want to delete this course?")) {
        btn.closest("tr").remove();
    }
}

// 4. معالجة الـ Submit (إضافة أو تعديل)
document.getElementById("addCourseForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const name = this.querySelectorAll('input')[0].value;
    const code = this.querySelectorAll('input')[1].value;
    const instructor = this.querySelector('select').options[this.querySelector('select').selectedIndex].text;
    const sections = this.querySelectorAll('input')[2].value;

    if (currentRow) {
        // حالة التعديل: تحديث الصف الحالي
        currentRow.cells[0].innerText = code;
        currentRow.cells[1].innerText = name;
        currentRow.cells[2].innerText = instructor;
        currentRow.cells[4].innerText = sections;
    } else {
        // حالة الإضافة: صف جديد
        const tableBody = document.querySelector("table tbody");
        const newRow = document.createElement("tr");

        newRow.innerHTML = `
            <td>${code}</td>
            <td>${name}</td>
            <td>${instructor}</td>
            <td>0</td> <td>${sections}</td>
            <td class="action-btns">
                <button class="btn-edit" onclick="editCourse(this)">Edit</button>
                <button class="btn-delete" onclick="deleteCourse(this)"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tableBody.appendChild(newRow);
    }

    closeModal();
});

// قفل المودال عند الضغط بره
window.onclick = function(event) {
    const modal = document.getElementById("courseModal");
    if (event.target == modal) closeModal();
}