document.addEventListener('DOMContentLoaded', () => {
    // 1. عرض اسم المستخدم المخزن من صفحة اللوجن
    const userNameDisplay = document.getElementById('userNameDisplay');
    const loggedUser = localStorage.getItem('loggedUser');
    
    if (loggedUser && userNameDisplay) {
        userNameDisplay.textContent = loggedUser;
    }

    // 2. منطق تحجيم السايد بار (Resizable Sidebar)
    const sidebar = document.getElementById("resizableSidebar");
    const resizer = document.getElementById("sidebarResizer");

    if (resizer && sidebar) {
        resizer.addEventListener("mousedown", (e) => {
            e.preventDefault();
            document.addEventListener("mousemove", resize);
            document.addEventListener("mouseup", stopResize);
            resizer.classList.add("resizing");
            document.body.style.cursor = "col-resize"; // تغيير شكل الماوس أثناء السحب
        });

        function resize(e) {
            // العرض الجديد بناءً على حركة الماوس
            let newWidth = e.clientX;
            
            // حدود التحجيم (أقل عرض 200px وأقصى عرض 450px)
            if (newWidth > 200 && newWidth < 450) {
                sidebar.style.width = newWidth + "px";
            }
        }

        function stopResize() {
            document.removeEventListener("mousemove", resize);
            document.removeEventListener("mouseup", stopResize);
            resizer.classList.remove("resizing");
            document.body.style.cursor = "default";
        }
    }
});

// 3. دالة تسجيل الخروج
function logout() {
    localStorage.removeItem('loggedUser');
    // سينتقل المستخدم تلقائياً عبر الرابط الموجود في الـ HTML
}