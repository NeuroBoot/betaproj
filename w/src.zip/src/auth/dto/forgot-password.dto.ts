export class ForgotPasswordDto {}
