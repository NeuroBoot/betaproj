export class AbstractRepository {}
